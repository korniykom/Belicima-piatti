function App() {
  return <h1>Belicima-piatti</h1>;
}

export default App;
